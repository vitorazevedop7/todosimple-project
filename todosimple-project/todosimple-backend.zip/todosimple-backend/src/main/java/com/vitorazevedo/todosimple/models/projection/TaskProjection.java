package com.vitorazevedo.todosimple.models.projection;

public interface TaskProjection {

    Long getId();

    String getDescription();

}
